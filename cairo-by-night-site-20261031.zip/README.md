# Cairo By Night Festival

Premium responsive website for Cairo By Night Festival 2027 in Serres, Greece.

## Local preview

```bash
python3 -m http.server 4180
```

Then open `http://127.0.0.1:4180/`.
