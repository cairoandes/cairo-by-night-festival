const page = document.body.dataset.page;

const navItems = [
  ['home', 'HOME', '/'],
  ['team', 'TEAM', '/team24/'],
  ['prices', 'PRICES', '/prices/'],
  ['rules', 'COMPETITION RULES', '/competition-rules/'],
  ['schedule', 'SCHEDULE', '/schedule/'],
  ['contact', 'CONTACT', '/contact-us/']
];

const header = document.querySelector('#site-header');
header.innerHTML = `
  <header class="site-header" aria-label="Main navigation">
    <div class="nav-shell">
      <a class="brand" href="/" aria-label="Cairo By Night home">
        <span class="brand-copy">Cairo By Night<small>Oriental Festival</small></span>
      </a>
      <button class="menu-toggle" type="button" aria-label="Open menu" aria-expanded="false"><span></span><span></span></button>
      <ul class="nav-links">
        ${navItems.map(([id, label, href]) => `<li><a href="${href}" ${page === id ? 'aria-current="page"' : ''}>${label}</a></li>`).join('')}
      </ul>
      <a class="nav-cta" href="/registration/">Book Now <span class="link-arrow" aria-hidden="true"></span></a>
    </div>
  </header>`;

document.querySelector('#site-footer').innerHTML = `
  <footer class="site-footer">
    <div class="footer-grid">
      <div><div class="footer-title">Cairo By Night</div><p class="footer-copy">The Ultimate Oriental Festival.</p></div>
      <div><div class="footer-label">Explore</div><ul class="footer-links">${navItems.map(([, label, href]) => `<li><a href="${href}">${label}</a></li>`).join('')}</ul></div>
      <div><div class="footer-label">Connect</div><ul class="footer-links"><li><a href="https://www.facebook.com/profile.php?id=100064596523501" target="_blank" rel="noopener">Facebook <span class="link-arrow" aria-hidden="true"></span></a></li><li><a href="https://www.instagram.com/cairo_by_night_festival_greece/" target="_blank" rel="noopener">Instagram <span class="link-arrow" aria-hidden="true"></span></a></li><li><a href="/registration/">Book Now</a></li></ul></div>
    </div>
    <div class="footer-bottom"><span>Copyright © 2027 CBN. All Rights Reserved.</span><span>Serres, Greece</span></div>
  </footer>`;

const main = document.querySelector('#main');
const pageHero = (kicker, title, lead = '', edition = '2027') => `<section class="page-hero page-hero-premium" data-title="${title}">
  <div class="page-hero-atmosphere" aria-hidden="true"></div>
  <div class="page-hero-stars" aria-hidden="true">${Array.from({ length: 22 }, (_, index) => `<i style="--i:${index};--x:${((index * 41) % 92) + 4}%;--y:${((index * 29) % 76) + 12}%"></i>`).join('')}</div>
  <div class="page-hero-inner">
    <div class="page-hero-layout">
      <div class="page-hero-copy">
        <div class="page-hero-kicker"><span></span>${kicker}</div>
        <h1 class="page-title">${title}</h1>
        ${lead ? `<p class="page-lead">${lead}</p>` : ''}
        <div class="page-hero-meta"><span>Cairo By Night</span><i>✦</i><span>Serres · Greece</span></div>
      </div>
      <div class="page-hero-logo" aria-label="Cairo By Night Festival">
        <span>Cairo</span>
        <em>By Night</em>
        <strong><img src="/assets/images/festival-signature-reference.png" alt="Festival"></strong>
      </div>
    </div>
  </div>
  <div class="page-hero-edition">Oriental Festival · ${edition}</div>
</section>`;

const scheduleDays = [
  { day: 'Tuesday', date: '4 August', events: [
    { time: 'All day', title: 'Registration' },
    { time: '12:00 – 20:00', title: 'Workshops' },
    { time: '22:00', title: 'International Opening Gala Show', note: 'and Greek Night', feature: true }
  ] },
  { day: 'Wednesday', date: '5 August', events: [
    { time: '9:45 – 20:00', title: 'Workshops' },
    { time: '22:00', title: 'International Gala Show', feature: true }
  ] },
  { day: 'Thursday', date: '6 August', events: [
    { time: '9:45 – 20:00', title: 'Workshops' },
    { time: '22:00', title: 'International Gala Show', feature: true }
  ] },
  { day: 'Friday', date: '7 August', events: [
    { time: '9:45 – 20:00', title: 'Workshops' },
    { time: '22:00', title: 'International Gala Show', note: 'Red Night', feature: true, accent: true }
  ] },
  { day: 'Saturday', date: '8 August', events: [
    { time: '9:45 – 20:00', title: 'Workshops' },
    { time: '22:00', title: 'Instructors Gala Show', feature: true }
  ] },
  { day: 'Sunday', date: '9 August', events: [
    { time: '', title: 'Competition', feature: true }
  ] }
];

const scheduleColumn = (scheduleDay, index) => `<article class="schedule-day-column ${index === 0 ? 'selected' : ''}" tabindex="0" data-day="${index}" aria-label="${scheduleDay.day}, ${scheduleDay.date}">
  <header><span>${scheduleDay.day}</span><strong>${scheduleDay.date.split(' ')[0]}</strong><small>${scheduleDay.date.split(' ')[1]}</small></header>
  <div class="schedule-column-events">${scheduleDay.events.map(event => `<div class="schedule-column-event ${event.feature ? 'featured' : ''} ${event.accent ? 'accent' : ''}">${event.time ? `<time>${event.time}</time>` : ''}<h3>${event.title}</h3>${event.note ? `<p>${event.note}</p>` : ''}</div>`).join('')}</div>
</article>`;

const artists = [
  { name: 'Dina', role: '', location: 'Egypt', image: 'dina' },
  { name: 'Randa Kamel', role: 'Master Teacher', location: 'Egypt', image: 'randa-kamel' },
  { name: 'Kazafy', role: 'Master Teacher', location: 'Egypt', image: 'kazafy' },
  { name: 'Mohanned Hawaz', role: 'Master Teacher', location: 'Iraq', image: 'mohanned-hawaz' },
  { name: 'Dr. Thawra Yousif Yaqoub', role: 'Master Teacher', location: 'Basra / Iraq', image: 'dr-thawra-yousif-yaqoub' },
  { name: 'Vaagn Tadevosyan', role: 'Master Teacher', location: 'Armenia / Russia', image: 'vaagn-tadevosyan' },
  { name: 'David Abraham', role: 'Master Teacher', location: 'Argentina', image: 'david-abraham' },
  { name: 'Atida Bogomolova', role: 'Master Teacher', location: 'Italy', image: 'atida-bogomolova' }
];

const heroLaurel = side => {
  const id = `hero-laurel-${side}`;
  return `<svg class="hero-laurel hero-laurel-${side}" viewBox="0 0 180 520" aria-hidden="true" focusable="false">
    <defs>
      <linearGradient id="${id}-gold" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#65400f"/><stop offset=".16" stop-color="#b87521"/><stop offset=".33" stop-color="#fff1b2"/><stop offset=".47" stop-color="#c48125"/><stop offset=".64" stop-color="#f6d782"/><stop offset=".8" stop-color="#8f5817"/><stop offset="1" stop-color="#e5b95d"/></linearGradient>
      <linearGradient id="${id}-silver" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#57534b"/><stop offset=".2" stop-color="#a9a28d"/><stop offset=".42" stop-color="#fff8da"/><stop offset=".58" stop-color="#8f8878"/><stop offset=".78" stop-color="#d8cba4"/><stop offset="1" stop-color="#716242"/></linearGradient>
      <filter id="${id}-glow" x="-80%" y="-80%" width="260%" height="260%"><feGaussianBlur stdDeviation="2.4" result="blur"/><feMerge><feMergeNode in="blur"/><feMergeNode in="SourceGraphic"/></feMerge></filter>
      <filter id="${id}-metal" x="-25%" y="-25%" width="150%" height="150%" color-interpolation-filters="sRGB">
        <feTurbulence type="fractalNoise" baseFrequency=".025 .16" numOctaves="3" seed="8" result="grain"/>
        <feColorMatrix in="grain" type="saturate" values="0" result="mono-grain"/>
        <feComponentTransfer in="mono-grain" result="soft-grain"><feFuncA type="table" tableValues="0 .38"/></feComponentTransfer>
        <feComposite in="soft-grain" in2="SourceAlpha" operator="in" result="metal-texture"/>
        <feBlend in="SourceGraphic" in2="metal-texture" mode="soft-light" result="textured-metal"/>
        <feSpecularLighting in="mono-grain" surfaceScale="2.4" specularConstant=".82" specularExponent="22" lighting-color="#fff1bf" result="specular"><feDistantLight azimuth="225" elevation="54"/></feSpecularLighting>
        <feComposite in="specular" in2="SourceAlpha" operator="in" result="metal-shine"/>
        <feBlend in="textured-metal" in2="metal-shine" mode="screen"/>
      </filter>
      <g id="${id}-leaf"><path d="M0 0C13-27 42-39 68-25C58 3 27 18 0 0Z"/><path d="M5-1C24-8 42-16 61-24" fill="none" stroke="rgba(80,48,12,.58)" stroke-width="1.15" stroke-linecap="round"/><path d="M24-8L17-21M36-13L33-28M47-18L49-29" fill="none" stroke="rgba(255,238,183,.34)" stroke-width=".7" stroke-linecap="round"/></g>
    </defs>
    <path class="hero-laurel-stem" d="M159 505C91 466 42 402 31 328C18 239 56 143 151 28"/>
    <g class="hero-laurel-leaves" fill="url(#${id}-gold)" filter="url(#${id}-metal)">
      <use href="#${id}-leaf" transform="translate(140 473) rotate(-148) scale(.62)"/><use href="#${id}-leaf" transform="translate(113 446) rotate(-162) scale(.72)"/>
      <use href="#${id}-leaf" transform="translate(82 410) rotate(-168) scale(.78)"/><use href="#${id}-leaf" transform="translate(58 367) rotate(-174) scale(.82)"/>
      <use href="#${id}-leaf" transform="translate(42 320) rotate(178) scale(.83)"/><use href="#${id}-leaf" transform="translate(39 271) rotate(167) scale(.8)"/>
      <use href="#${id}-leaf" transform="translate(48 220) rotate(153) scale(.76)"/><use href="#${id}-leaf" transform="translate(67 171) rotate(142) scale(.71)"/>
      <use href="#${id}-leaf" transform="translate(94 124) rotate(132) scale(.64)"/><use href="#${id}-leaf" transform="translate(125 78) rotate(123) scale(.56)"/>
    </g>
    <g class="hero-laurel-leaves hero-laurel-leaves-inner" fill="url(#${id}-gold)" filter="url(#${id}-metal)">
      <use href="#${id}-leaf" transform="translate(124 462) rotate(-38) scale(.48)"/><use href="#${id}-leaf" transform="translate(91 426) rotate(-25) scale(.58)"/>
      <use href="#${id}-leaf" transform="translate(62 383) rotate(-12) scale(.65)"/><use href="#${id}-leaf" transform="translate(44 335) rotate(2) scale(.67)"/>
      <use href="#${id}-leaf" transform="translate(40 285) rotate(15) scale(.66)"/><use href="#${id}-leaf" transform="translate(47 235) rotate(27) scale(.63)"/>
      <use href="#${id}-leaf" transform="translate(64 187) rotate(37) scale(.58)"/><use href="#${id}-leaf" transform="translate(88 142) rotate(47) scale(.52)"/>
      <use href="#${id}-leaf" transform="translate(116 99) rotate(56) scale(.46)"/>
    </g>
    <g class="hero-laurel-sparks" filter="url(#${id}-glow)"><circle cx="38" cy="346" r="2.2"/><circle cx="58" cy="206" r="1.7"/><circle cx="105" cy="111" r="1.4"/><path d="M24 285h12M30 279v12"/><path d="M79 161h9M83.5 156.5v9"/></g>
  </svg>`;
};

const soloDanceCategories = ['Raks Sharki', 'Folklore / Baladi / Shaabi', 'Show Dance / CD Drum Solo', 'Pop / Modern Oriental'];
const groupDanceCategories = ['Egyptian Dances', 'Other Oriental Dances (Khaleej, Pop lyrical, Iraqi, Drum, Show dance…)'];

const competitionRuleCard = ({ title, subtitle, age, time, categories, price = '', accent = 'gold' }) => `<article class="competition-rule-card reveal" data-accent="${accent}">
  <span class="card-arabesque" aria-hidden="true"><i></i></span>
  <header><div><span>${subtitle}</span><h3>${title}</h3></div>${age ? `<strong>${age}</strong>` : ''}</header>
  <ol>${categories.map(category => `<li>${category}</li>`).join('')}</ol>
  <footer><span><i aria-hidden="true">◷</i> ${time}</span>${price ? `<strong>${price}</strong>` : ''}</footer>
</article>`;

const renderers = {
  home: () => `
    <section class="hero hero-premium">
      <div class="hero-media" aria-hidden="true"></div>
      <div class="hero-light hero-light-left" aria-hidden="true"></div><div class="hero-light hero-light-right" aria-hidden="true"></div>
      <div class="hero-stars" aria-hidden="true">${Array.from({ length: 36 }, (_, index) => `<i style="--star:${index + 1};--x:${((index * 37) % 94) + 3}%;--y:${((index * 53) % 90) + 5}%"></i>`).join('')}</div>
      <div class="hero-content hero-logo-stage">
        <div class="hero-overline"><span></span>The Ultimate Oriental Festival<span></span></div>
        <h1 class="hero-wordmark"><span>Cairo</span><em>By Night</em><strong><span class="sr-only">Festival</span><img src="/assets/images/festival-signature-reference.png" alt="" aria-hidden="true"></strong></h1>
        <div class="hero-submark">Oriental Festival <i>✦</i> Greece</div>
        <div class="hero-meta"><span>2027 Edition</span><i></i><span>Serres, Greece</span></div>
        <div class="hero-actions"><a class="hero-action primary" href="/registration/">Book Now <span class="link-arrow" aria-hidden="true"></span></a><a class="hero-action" href="/team24/">Discover the team <span class="link-arrow link-arrow-forward" aria-hidden="true"></span></a></div>
      </div><div class="hero-index">Cairo By Night · Greece</div><div class="scroll-cue" aria-hidden="true"></div>
    </section>
    <section class="section announcement-section"><div class="section-shell announcement-shell">
      <article class="festival-announcement reveal" aria-labelledby="festival-announcement-title">
        <div class="announcement-aura" aria-hidden="true"></div>
        <div class="announcement-topline"><span>Festival</span><small>Presented by</small><strong>Stella Zahir</strong></div>
        <p class="announcement-manifesto">The ultimate festival of<br>Egyptian and Arab arts &amp; dances</p>
        <div class="announcement-date">
          <span>Save the dates</span>
          <div class="date-range"><strong>3</strong><i>—</i><strong>8</strong></div>
          <h2 id="festival-announcement-title">August</h2>
          <b>2027</b>
        </div>
        <div class="announcement-place"><span>Greece</span><i>✦</i><span>Serres</span></div>
        <div class="announcement-footer"><span>Dance</span><i></i><span>Culture</span><i></i><span>Connection</span></div>
        <div class="announcement-contact"><span>www.cairobynight.com</span><span>@cairobynightfestival</span></div>
      </article>
    </div></section>
    <section class="section discover-greece-section" aria-labelledby="discover-greece-title"><div class="section-shell">
      <header class="discover-greece-heading reveal"><div><span>Beyond the stage</span><h2 id="discover-greece-title">Dance &amp;<br>Discover Greece</h2></div><p>A festival journey shaped by movement, culture and connection in Serres, Greece.</p></header>
      <div class="discover-greece-experience reveal" data-discover-active="dance">
        <div class="discover-greece-visual" aria-hidden="true">
          <img class="discover-photo discover-photo-dance" src="/assets/images/home/festival-dance.jpg" alt="" loading="lazy">
          <img class="discover-photo discover-photo-culture" src="/assets/images/home/serres-landscape.jpg" alt="" loading="lazy">
          <img class="discover-photo discover-photo-connect" src="/assets/images/home/festival-connect.jpg" alt="" loading="lazy">
          <div class="discover-photo-vignette"></div>
          <div class="discover-photo-caption discover-caption-dance"><small>Real festival moment</small><span>Cairo By Night</span><strong>Dance</strong></div>
          <div class="discover-photo-caption discover-caption-culture"><small>Discover the destination</small><span>Serres</span><strong>Greece</strong></div>
          <div class="discover-photo-caption discover-caption-connect"><small>One international community</small><span>Meet. Share.</span><strong>Connect.</strong></div>
        </div>
        <div class="discover-greece-content">
          <div class="discover-tabs" role="tablist" aria-label="Discover the festival experience">
            <button class="active" type="button" role="tab" aria-selected="true" aria-controls="discover-panel-dance" id="discover-tab-dance" data-discover-tab="dance"><span>01</span>Dance</button>
            <button type="button" role="tab" aria-selected="false" aria-controls="discover-panel-culture" id="discover-tab-culture" data-discover-tab="culture"><span>02</span>Culture</button>
            <button type="button" role="tab" aria-selected="false" aria-controls="discover-panel-connect" id="discover-tab-connect" data-discover-tab="connect"><span>03</span>Connect</button>
          </div>
          <div class="discover-panels">
            <article id="discover-panel-dance" role="tabpanel" aria-labelledby="discover-tab-dance" data-discover-panel="dance"><span>Movement</span><h3>Dance from day<br>into night.</h3><p>Workshops, performances and gala moments come together in one immersive festival experience.</p><a href="/schedule/">Explore the schedule <i class="link-arrow" aria-hidden="true"></i></a></article>
            <article id="discover-panel-culture" role="tabpanel" aria-labelledby="discover-tab-culture" data-discover-panel="culture" hidden><span>Place</span><h3>Discover the<br>festival city.</h3><p>Experience Cairo By Night in Serres, Greece, where the festival extends beyond the stage.</p><a href="/contact-us/">Find the festival <i class="link-arrow" aria-hidden="true"></i></a></article>
            <article id="discover-panel-connect" role="tabpanel" aria-labelledby="discover-tab-connect" data-discover-panel="connect" hidden><span>Community</span><h3>Meet artists from<br>around the world.</h3><p>Share the floor, the stage and unforgettable festival nights with an international dance community.</p><a href="/team24/">Meet the team <i class="link-arrow" aria-hidden="true"></i></a></article>
          </div>
        </div>
      </div>
    </div></section>
    <section class="festival-film-section" aria-labelledby="festival-film-title"><div class="festival-film-shell">
      <div class="festival-film-copy reveal"><span>Festival film · Cairo By Night</span><h2 id="festival-film-title">Feel the<br><em>night.</em></h2><p>A glimpse of the movement, artistry and stage energy that define Cairo By Night Festival.</p><a href="https://www.youtube.com/@cairobynightfest" target="_blank" rel="noopener">Visit the festival channel <i class="link-arrow" aria-hidden="true"></i></a></div>
      <div class="festival-film-frame reveal"><iframe src="https://www.youtube-nocookie.com/embed/olcbg52pzfQ?rel=0&amp;modestbranding=1" title="Cairo By Night Festival performance film" loading="lazy" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe><div class="festival-film-label"><span>Watch</span><strong>Cairo By Night</strong></div></div>
    </div></section>
    <section class="section home-registration-section" aria-labelledby="home-registration-title"><div class="section-shell home-registration-shell reveal">
      <div class="registration-orbit" aria-hidden="true"></div><span class="registration-index">2027 · Serres, Greece</span>
      <div class="home-registration-copy"><div class="eyebrow">Cairo By Night</div><h2 id="home-registration-title">Registration<br><em>soon...</em></h2><p>3—8 August 2027 · The Ultimate Oriental Festival</p></div>
      <div class="home-registration-actions"><a class="hero-action primary" href="/registration/">Registration details <span class="link-arrow" aria-hidden="true"></span></a><a class="feature-link" href="https://drive.google.com/drive/folders/1-7z5vOrJZgiurhji9NpLeCVCcikGB3rI?usp=sharing" target="_blank" rel="noopener"><span>CBN 2027 Competition Results</span><span class="link-arrow" aria-hidden="true"></span></a></div>
    </div></section>
    <section class="section arrival-section" aria-labelledby="arrival-title"><div class="section-shell">
      <div class="section-heading arrival-heading reveal"><div><div class="section-kicker">Arrival information</div><span class="arrival-code">AIR / P5 / CBN</span></div><h2 class="section-title" id="arrival-title">Meeting point<br>& transfer</h2></div>
      <div class="arrival-experience reveal" data-active="1">
        <div class="arrival-map" aria-label="Illustrated route from the airport terminal to the Parking 5 meeting point">
          <div class="map-topline"><span>Airport route</span><span>Follow the illuminated path</span></div>
          <svg class="route-map" viewBox="0 0 900 620" role="img" aria-labelledby="route-map-title route-map-description">
            <title id="route-map-title">Route to Parking Number 5</title>
            <desc id="route-map-description">Walk straight from the terminal, turn right, pass Grigoris Café and the car rental area, and reach the meeting point near the coach buses.</desc>
            <defs>
              <linearGradient id="terminal-fill" x1="0" x2="1"><stop stop-color="#171825"/><stop offset="1" stop-color="#0b0d16"/></linearGradient>
              <linearGradient id="route-glow" x1="0" x2="1"><stop stop-color="#65d8ff"/><stop offset=".55" stop-color="#9a73ff"/><stop offset="1" stop-color="#ffba61"/></linearGradient>
              <filter id="route-blur"><feGaussianBlur stdDeviation="7"/></filter>
              <pattern id="map-grid" width="38" height="38" patternUnits="userSpaceOnUse"><path d="M38 0H0V38" fill="none" stroke="#fff" stroke-opacity=".045"/></pattern>
            </defs>
            <rect width="900" height="620" fill="url(#map-grid)"/>
            <path class="map-road" d="M112 344H426V474H744"/>
            <path class="map-route-glow" d="M112 344H426V474H744"/>
            <path class="map-route" d="M112 344H426V474H744"/>
            <g class="map-terminal">
              <path d="M58 140H292L330 184V344H58Z" fill="url(#terminal-fill)" stroke="#65d8ff" stroke-opacity=".45"/>
              <path d="M82 178H278M82 216H300M82 254H300" stroke="#fff" stroke-opacity=".08"/>
              <path d="M108 294H196V344H108Z" fill="#65d8ff" fill-opacity=".12" stroke="#65d8ff" stroke-opacity=".55"/>
              <text x="58" y="116" class="map-label-small">AIRPORT</text><text x="58" y="91" class="map-label-large">TERMINAL</text>
            </g>
            <g class="map-landmark cafe"><circle cx="426" cy="262" r="48"/><path d="M408 250h31v18c0 13-8 22-16 22s-15-9-15-22zm31 4h8c9 0 9 14 0 14h-8"/><text x="426" y="208" text-anchor="middle">GRIGORIS CAFÉ</text></g>
            <g class="map-landmark rental"><rect x="536" y="356" width="120" height="54" rx="8"/><path d="M558 387h74l-10-18h-45zM568 387a9 9 0 1 0 0 18 9 9 0 0 0 0-18zm54 0a9 9 0 1 0 0 18 9 9 0 0 0 0-18z"/><text x="596" y="338" text-anchor="middle">CAR RENTAL</text></g>
            <g class="map-parking"><path d="M684 250h132v142H684z"/><text x="750" y="305" text-anchor="middle" class="parking-p">P</text><text x="750" y="355" text-anchor="middle" class="parking-five">5</text></g>
            <g class="map-buses"><rect x="672" y="508" width="84" height="35" rx="7"/><path d="M686 518h24v13h-24zm30 0h24v13h-24z"/><circle cx="690" cy="546" r="7"/><circle cx="738" cy="546" r="7"/><text x="714" y="575" text-anchor="middle">COACH BUSES</text></g>
            <g class="map-stage" data-map-stage="1"><circle cx="112" cy="344" r="21"/><text x="112" y="350" text-anchor="middle">1</text></g>
            <g class="map-stage" data-map-stage="2"><circle cx="426" cy="474" r="21"/><text x="426" y="480" text-anchor="middle">2</text></g>
            <g class="map-stage" data-map-stage="3"><circle cx="744" cy="474" r="21"/><text x="744" y="480" text-anchor="middle">3</text><circle class="meeting-pulse" cx="744" cy="474" r="42"/></g>
            <g class="map-you"><path d="M744 424l-9-17h18z"/><text x="744" y="397" text-anchor="middle">MEETING POINT</text></g>
          </svg>
          <div class="map-legend"><span><i class="legend-route"></i>Walking route</span><span><i class="legend-point"></i>Meeting point</span></div>
        </div>
        <div class="arrival-guide">
          <div class="guide-intro"><span>Dear artist</span><p>Instructions to reach Parking Number 5 and the meeting point.</p></div>
          <div class="stage-tabs" role="tablist" aria-label="Arrival stages">
            <button type="button" class="stage-tab active" role="tab" aria-selected="true" aria-controls="arrival-stage-1" id="arrival-tab-1" data-stage="1"><span>01</span>Arrival</button>
            <button type="button" class="stage-tab" role="tab" aria-selected="false" aria-controls="arrival-stage-2" id="arrival-tab-2" data-stage="2"><span>02</span>Parking 5</button>
            <button type="button" class="stage-tab" role="tab" aria-selected="false" aria-controls="arrival-stage-3" id="arrival-tab-3" data-stage="3"><span>03</span>Meeting</button>
          </div>
          <div class="stage-panels" aria-live="polite">
            <article class="stage-panel" id="arrival-stage-1" role="tabpanel" aria-labelledby="arrival-tab-1"><span>Stage 1</span><h3>Arrival and Initial Directions</h3><div class="stage-panel-body"><p>As soon as you arrive at the airport, follow the signs for Parking Number 5. These signs will direct you to the area where the coach buses are parked.</p><button class="arrival-photo-button" type="button" data-photo="photo-stage-1" data-caption="Follow the airport signs for Parking Number 5" aria-label="Enlarge photo of the airport signs"><span class="arrival-photo-preview photo-stage-1" aria-hidden="true"></span><small>View photo <i class="link-arrow" aria-hidden="true"></i></small></button></div></article>
            <article class="stage-panel" id="arrival-stage-2" role="tabpanel" aria-labelledby="arrival-tab-2" hidden><span>Stage 2</span><h3>Navigating to Parking Number 5</h3><div class="stage-panel-body"><p>Parking Number 5 is located towards the end of the airport complex. As you walk out of the terminal, proceed straight and then take a right. You should see Parking Number 5 on your right-hand side at the end of the airport.</p><button class="arrival-photo-button" type="button" data-photo="photo-stage-2" data-caption="Proceed straight and then turn right towards Parking Number 5" aria-label="Enlarge photo of the route outside the terminal"><span class="arrival-photo-preview photo-stage-2" aria-hidden="true"></span><small>View photo <i class="link-arrow" aria-hidden="true"></i></small></button></div></article>
            <article class="stage-panel" id="arrival-stage-3" role="tabpanel" aria-labelledby="arrival-tab-3" hidden><span>Stage 3</span><h3>Landmarks and Final Steps</h3><div class="stage-panel-body"><p>While walking towards Parking Number 5, you will pass Grigoris Café. Continue past the café, and you will see a car rental area next to Parking Number 5. Look for the label marked “Meeting Point” near the coach buses.</p><button class="arrival-photo-button" type="button" data-photo="photo-stage-3" data-caption="Parking 5 meeting point near the coach buses" aria-label="Enlarge photo of the Parking 5 meeting point"><span class="arrival-photo-preview photo-stage-3" aria-hidden="true"></span><small>View photo <i class="link-arrow" aria-hidden="true"></i></small></button></div></article>
          </div>
          <div class="assistant-beacon"><button class="arrival-photo-button assistant-photo" type="button" data-photo="photo-assistant" data-caption="The CBN assistant waiting spot at Parking 5" aria-label="Enlarge photo of the CBN assistant waiting spot"><span class="arrival-photo-preview photo-assistant" aria-hidden="true"></span><small>Waiting spot <i class="link-arrow" aria-hidden="true"></i></small></button><div><span>Look for the CBN assistant</span><strong>Dear artists, an assistant will wait for you at Parking 5 on Meeting Point.</strong></div></div>
        </div>
      </div>
      <dialog class="arrival-photo-dialog" id="arrival-photo-dialog" aria-labelledby="arrival-photo-title"><div class="arrival-photo-dialog-inner"><div class="dialog-topline"><span id="arrival-photo-title">Arrival reference photo</span><button type="button" class="dialog-close" aria-label="Close enlarged photo">Close <i aria-hidden="true">×</i></button></div><div class="arrival-photo-expanded" role="img"></div><p class="arrival-photo-caption"></p></div></dialog>
    </div></section>`,
  team: () => `${pageHero('Artists & instructors', 'The Team', 'Meet the confirmed artists and master teachers of Cairo By Night Festival 2027. Dance, culture and connection come together in Serres, Greece.', '2027')}<section class="content-section team-roster-section"><div class="roster-header reveal"><span>CBN 2027 · Confirmed team</span><strong>${artists.length} artists & instructors</strong></div><div class="roster-list">${artists.map((artist, index) => `<article class="roster-row reveal"><span class="roster-index">${String(index + 1).padStart(2, '0')}</span><figure class="roster-thumb"><img src="/assets/images/team-2027/${artist.image}.webp" alt="${artist.name}, ${artist.location}" width="720" height="900" loading="lazy"></figure><div class="roster-identity"><h2 class="roster-name">${artist.name}</h2><div class="roster-details">${artist.role ? `<span>${artist.role}</span>` : ''}<strong>${artist.location}</strong></div></div><span class="roster-mark" aria-hidden="true">✦</span></article>`).join('')}</div></section>`,
  prices: () => `${pageHero('Festival access', 'Prices', 'For prices of Cairo By Night 2025 please contact us: cairobynight2025@gmail.com')}
    <section class="content-section pricing-section">
      <div class="pricing-shell">
        <div class="pricing-heading reveal">
          <div><span class="pricing-overline">The Mitos of Ariadne</span><h2>Basic & Full<br>Packages</h2></div>
          <p>5 nights or 6 nights in Resort & Spa Hotel. Package prices are per person.</p>
        </div>
        <div class="package-grid">
          <article class="package-card reveal">
            <span class="card-arabesque" aria-hidden="true"><i></i></span>
            <header class="package-head"><div><span>30 July — 3 August</span><h3>Basic Package</h3><small>5 nights · per person</small></div><strong>05</strong></header>
            <p class="package-note">6th day of competition is not included</p>
            <ul class="package-includes"><li>5 nights in Resort & Spa Hotel</li><li>3 meals per day (breakfast - lunch - dinner)</li><li>All workshops (with more than 20 teachers)</li><li>Entrances at parties (GIFT from Festival)</li><li>Performance fee (CD)</li></ul>
            <div class="room-prices"><div><span>Single room</span><strong>780 €</strong></div><div><span>Double room</span><strong>675 €</strong></div><div><span>Triple room</span><strong>655 €</strong></div><div><span>Junior suite <small>4 people</small></span><strong>645 €</strong></div></div>
          </article>
          <article class="package-card featured reveal">
            <span class="card-arabesque" aria-hidden="true"><i></i></span>
            <div class="package-ribbon">Full experience</div>
            <header class="package-head"><div><span>30 July — 4 August</span><h3>Full Package</h3><small>6 nights · per person</small></div><strong>06</strong></header>
            <p class="package-note">6 nights in Resort & Spa Hotel</p>
            <ul class="package-includes"><li>6 nights in Resort & Spa Hotel</li><li>3 meals per day (breakfast - lunch - dinner)</li><li>All workshops (with more than 20 teachers)</li><li>Entrances at parties (GIFT from Festival)</li><li>Performance fee (CD)</li></ul>
            <div class="room-prices"><div><span>Single room</span><strong>860 €</strong></div><div><span>Double room</span><strong>730 €</strong></div><div><span>Triple room</span><strong>710 €</strong></div><div><span>Junior suite <small>4 people</small></span><strong>700 €</strong></div></div>
          </article>
        </div>
        <div class="travel-extras reveal">
          <article><span class="extra-index">01</span><div><h3>Transfer</h3><p>Transfer from airport to Hotel and back. <strong>35€</strong> per route with bus between 08:00 to 20:00.</p><p>Private car <strong>75€</strong> per route. Taxi <strong>150€</strong> per route.</p></div></article>
          <article><span class="extra-index">02</span><div><h3>Extra nights</h3><p>Only breakfast included.</p><p><strong>65€</strong> per person for double or triple room<br><strong>85€</strong> per person for single room</p></div></article>
        </div>
        <div class="deposit-banner reveal"><span>Deposit</span><strong>300 euro is non-refundable</strong></div>
        <section class="access-pricing reveal" aria-labelledby="access-title">
          <div class="access-intro"><span class="pricing-overline">Hotel not included</span><h2 id="access-title">Festival access</h2></div>
          <div class="access-list">
            <article><div><span>All workshops</span><h3>Full Pass</h3></div><strong>420 €</strong></article>
            <article><div><span>Minimum 5 workshops</span><h3>Single Workshops</h3></div><strong>70 € <small>each</small></strong></article>
            <article><div><span>1 performance is FREE for guests with full pass</span><h3>Performance Fee (CD)</h3></div><strong>30 € <small>extra performances</small></strong></article>
            <article><div><span>Per category</span><h3>Competition Fee</h3></div><strong>30 €</strong></article>
            <article><div><span>Performance</span><h3>Live Band Performance Fee</h3></div><strong>30 €</strong></article>
          </div>
        </section>
        <div class="price-contact reveal"><span>Price information</span><a href="mailto:CairoByNight2024@gmail.com">CairoByNight2024@gmail.com <span class="link-arrow" aria-hidden="true"></span></a></div>
        <div class="notice reveal"><strong>Discount information</strong><br>If you have a discount or a discount coupon for our festival, you must submit it along with your Registration Form. Otherwise, it will not be considered at the last moment upon our arrival.</div>
      </div>
    </section>`,
  rules: () => `${pageHero('Competition', 'Categories & Rules', 'Choose your format and compare every level, category, age requirement, music limit and fee.')}<section class="content-section competition-rules-section"><div class="competition-rules-shell">
    <header class="competition-rules-heading reveal"><div><span>Competition guide · 2027</span><h2>Find your<br>category</h2></div><p>All information from the official competition documents, rebuilt as an accessible and easy-to-compare guide.</p></header>
    <div class="competition-mode-switch reveal" role="tablist" aria-label="Competition format"><button class="active" id="rules-solo-tab" type="button" role="tab" aria-selected="true" aria-controls="rules-solo-panel" data-rules-panel="solo"><span>01</span>Solo Competition</button><button id="rules-group-tab" type="button" role="tab" aria-selected="false" aria-controls="rules-group-panel" data-rules-panel="group"><span>02</span>Group Competition</button></div>
    <section class="competition-rules-panel" id="rules-solo-panel" role="tabpanel" aria-labelledby="rules-solo-tab" data-rules-content="solo">
      <div class="rules-panel-intro reveal"><span>Solo format</span><h2>Six paths.<br>One stage.</h2><p>Choose the level and age category that matches your competition profile.</p></div>
      <div class="competition-rule-grid competition-rule-grid-primary">
        ${competitionRuleCard({ title: 'Professional', subtitle: 'For Cairo By Night Queen / King', age: '+18', time: 'Music maximum 4 min', categories: soloDanceCategories, accent: 'blue' })}
        ${competitionRuleCard({ title: 'Semi-Professional', subtitle: 'For Cairo By Night Princess', age: '+16', time: 'Music maximum 3 min', categories: soloDanceCategories, accent: 'red' })}
        ${competitionRuleCard({ title: "Lady’s Category", subtitle: 'Open Level', age: '+35', time: 'Music maximum 4 min', categories: soloDanceCategories, accent: 'violet' })}
      </div>
      <aside class="competition-policy choreography-policy reveal"><span>Queen category requirement</span><h3>Original choreography</h3><p>At the Cairo By Night Queen Category: At least one of four choreographies presented in must be created and choreographed by the performer. Choreographies created by another choreographer may be included for the remaining routines.</p></aside>
      <div class="competition-rule-grid competition-rule-grid-secondary">
        ${competitionRuleCard({ title: 'Teens', subtitle: 'Youth category', age: '+11', time: 'Music maximum 3 min', categories: soloDanceCategories, accent: 'red' })}
        ${competitionRuleCard({ title: 'Children', subtitle: 'Youth category', age: '+6', time: 'Music maximum 3 min', categories: soloDanceCategories, accent: 'blue' })}
        ${competitionRuleCard({ title: 'Live Band Competition', subtitle: 'All ages', age: 'All ages', time: 'Music from 2 to 3 min', categories: ['Professionals', 'Semi-Professionals', 'Teens / Pre-Professionals'], accent: 'gold' })}
      </div>
      <aside class="competition-policy safeguarding-policy reveal"><span>Safeguarding note</span><h3>Teens and Children categories</h3><p>For the Teens and Children Categories, all performances must be strictly age appropriate. Costumes, choreography, music selection, makeup, styling, and stage presentation must not sexualize or portray minors in an adult manner. Parents or legal guardians and coaches are fully responsible for ensuring each participant’s overall presentation is appropriate for a youth competition, and by registering they confirm their acceptance of this responsibility.</p></aside>
      <div class="competition-fee reveal"><span>Solo competition fee</span><strong>40 €</strong></div>
    </section>
    <section class="competition-rules-panel" id="rules-group-panel" role="tabpanel" aria-labelledby="rules-group-tab" data-rules-content="group" hidden>
      <div class="rules-panel-intro reveal"><span>Group format</span><h2>Dance<br>together.</h2><p>Three group divisions with the same category structure and a fee calculated per participant.</p></div>
      <div class="competition-rule-grid competition-rule-grid-primary">
        ${competitionRuleCard({ title: 'Professional', subtitle: 'For Cairo By Night Queen', time: 'Music maximum 4 min', categories: groupDanceCategories, price: '15 € per person', accent: 'blue' })}
        ${competitionRuleCard({ title: 'Semi-Professional', subtitle: 'For Cairo By Night Princess', time: 'Music maximum 3 min', categories: groupDanceCategories, price: '15 € per person', accent: 'red' })}
        ${competitionRuleCard({ title: 'Teens + Children', subtitle: 'For Cairo By Night Prince', time: 'Music maximum 3 min', categories: groupDanceCategories, price: '15 € per person', accent: 'violet' })}
      </div>
      <div class="group-competition-banner reveal"><div><span>Stella Zahir Presents</span><h3>Cairo By Night</h3><p>The Ultimate Bellydance &amp; Arabic Culture Festival</p></div><strong>4—9<small>August 2027</small></strong></div>
    </section>
    <footer class="competition-rules-contact reveal"><div><span>Info &amp; registrations only</span><a href="https://www.cairobynight.gr/">www.cairobynight.gr</a></div><a href="mailto:cairobynight2027@gmail.com">cairobynight2027@gmail.com <i class="link-arrow" aria-hidden="true"></i></a></footer>
  </div></section>`,
  schedule: () => `${pageHero('Cairo By Night 2027', 'Schedule')}<section class="content-section schedule-section"><div class="schedule-shell">
    <header class="schedule-heading reveal"><div><span>Stella Zahir Presents</span><h2>The Ultimate Bellydance<br>&amp; Arabic Culture Festival</h2></div><strong>4—9<br><small>August · Greece</small></strong></header>
    <div class="schedule-zoom-bar reveal" aria-label="Schedule view controls">
      <button class="schedule-fit-button active" type="button" data-schedule-fit>All days</button>
      <div class="schedule-day-jumps" aria-label="Zoom into one day">${scheduleDays.map((scheduleDay, index) => `<button type="button" data-schedule-focus="${index}"><span>${scheduleDay.day.slice(0, 3)}</span>${scheduleDay.date.split(' ')[0]}</button>`).join('')}</div>
      <div class="schedule-zoom-buttons"><button type="button" data-schedule-zoom="out" aria-label="Zoom out">−</button><span data-schedule-zoom-level aria-live="polite">Fit</span><button type="button" data-schedule-zoom="in" aria-label="Zoom in">+</button></div>
    </div>
    <div class="schedule-board-frame reveal" aria-label="Cairo By Night schedule, 4 to 9 August" tabindex="0">
      <div class="schedule-board-stage">
      <div class="schedule-board">
        <div class="schedule-board-brand"><span>Cairo By Night</span><strong>Festival Schedule</strong><small>Greece · 2027</small></div>
        <div class="schedule-columns">${scheduleDays.map(scheduleColumn).join('')}</div>
      </div>
      </div>
    </div>
  </div></section>`,
  contact: () => `${pageHero('We are here', 'Contact')}<section class="content-section"><div class="contact-grid"><div class="contact-panel reveal"><div class="eyebrow">Festival desk</div><a class="contact-item" href="tel:%2000306972986504"><span>Telephone</span><strong>+306972986504 (Stella Zahir)</strong></a><a class="contact-item" href="mailto:cairobynight2027@gmail.com"><span>Email</span><strong>cairobynight2027@gmail.com</strong></a><div class="contact-item"><span>Venue</span><strong>Elpida Resort & Spa - Serres</strong></div></div><div class="map-wrap reveal"><iframe title="Elpida Resort Serres" src="https://maps.google.com/maps?q=Elpida%20Resort%20Serres&t=m&z=13&output=embed&iwloc=near" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe></div></div><div class="section-shell" style="margin-top:2rem"><h2 class="section-title reveal">Cairo By Night Bellydance Festival Event Map</h2></div></section>`,
  registration: () => `${pageHero('Cairo By Night 2027', 'Registration')}<section class="content-section"><div class="soldout reveal"><strong>Main Hotel SOLD OUT</strong><br>The main festival hotel is now fully booked. Rooms are still available at our second official hotel, Philippos Xenia, with the same amenities and quality. Please continue your registration through the Xenia option below</div><div class="registration-card reveal"><span class="status">Current status</span><h2>Registrations are closed</h2><a class="button" href="https://contaste.pro/eng/152716?register" target="_blank" rel="noopener">Register for Competition/Show Here (Also add your music) <span class="link-arrow" aria-hidden="true"></span></a></div></section>`
};

main.innerHTML = (renderers[page] || renderers.home)();

const siteHeader = document.querySelector('.site-header');
const menuButton = document.querySelector('.menu-toggle');
const menu = document.querySelector('.nav-links');
const mobileQuery = window.matchMedia('(max-width: 1050px)');

const syncMenuAccessibility = () => {
  menu.inert = mobileQuery.matches && !menu.classList.contains('open');
};

const setHeader = () => siteHeader.classList.toggle('scrolled', window.scrollY > 24);
setHeader();
window.addEventListener('scroll', setHeader, { passive: true });

menuButton.addEventListener('click', () => {
  const open = menu.classList.toggle('open');
  siteHeader.classList.toggle('menu-open', open);
  menuButton.setAttribute('aria-expanded', String(open));
  menuButton.setAttribute('aria-label', open ? 'Close menu' : 'Open menu');
  document.body.style.overflow = open ? 'hidden' : '';
  syncMenuAccessibility();
});

menu.addEventListener('click', event => {
  if (event.target.closest('a')) {
    menu.classList.remove('open');
    siteHeader.classList.remove('menu-open');
    menuButton.setAttribute('aria-expanded', 'false');
    menuButton.setAttribute('aria-label', 'Open menu');
    document.body.style.overflow = '';
    syncMenuAccessibility();
  }
});

document.addEventListener('keydown', event => {
  if (event.key === 'Escape' && menu.classList.contains('open')) {
    menu.classList.remove('open');
    siteHeader.classList.remove('menu-open');
    menuButton.setAttribute('aria-expanded', 'false');
    menuButton.setAttribute('aria-label', 'Open menu');
    document.body.style.overflow = '';
    syncMenuAccessibility();
    menuButton.focus();
  }
});

mobileQuery.addEventListener('change', () => {
  if (!mobileQuery.matches) {
    menu.classList.remove('open');
    siteHeader.classList.remove('menu-open');
    menuButton.setAttribute('aria-expanded', 'false');
    menuButton.setAttribute('aria-label', 'Open menu');
    document.body.style.overflow = '';
  }
  syncMenuAccessibility();
});
syncMenuAccessibility();

const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
if (!reducedMotion && 'IntersectionObserver' in window) {
  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('visible');
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.12, rootMargin: '0px 0px -40px' });
  document.querySelectorAll('.reveal').forEach(element => observer.observe(element));
} else {
  document.querySelectorAll('.reveal').forEach(element => element.classList.add('visible'));
}

if (!reducedMotion && page === 'home' && window.matchMedia('(pointer:fine)').matches) {
  const media = document.querySelector('.hero-media');
  window.addEventListener('pointermove', event => {
    const x = (event.clientX / window.innerWidth - .5) * 8;
    const y = (event.clientY / window.innerHeight - .5) * 8;
    media.style.transform = `translate3d(${x}px,${y}px,0) scale(1.015)`;
  }, { passive: true });
}

if (page === 'home') {
  const arrivalExperience = document.querySelector('.arrival-experience');
  const stageTabs = [...document.querySelectorAll('.stage-tab')];
  const stagePanels = [...document.querySelectorAll('.stage-panel')];
  const photoDialog = document.querySelector('#arrival-photo-dialog');
  const expandedPhoto = photoDialog.querySelector('.arrival-photo-expanded');
  const photoCaption = photoDialog.querySelector('.arrival-photo-caption');
  const closePhoto = photoDialog.querySelector('.dialog-close');

  stageTabs.forEach(tab => tab.addEventListener('click', () => {
    const activeStage = tab.dataset.stage;
    arrivalExperience.dataset.active = activeStage;
    stageTabs.forEach(item => {
      const isActive = item === tab;
      item.classList.toggle('active', isActive);
      item.setAttribute('aria-selected', String(isActive));
    });
    stagePanels.forEach(panel => {
      panel.hidden = panel.id !== `arrival-stage-${activeStage}`;
    });
  }));

  document.querySelectorAll('.arrival-photo-button').forEach(button => button.addEventListener('click', () => {
    expandedPhoto.className = `arrival-photo-expanded ${button.dataset.photo}`;
    expandedPhoto.setAttribute('aria-label', button.dataset.caption);
    photoCaption.textContent = button.dataset.caption;
    photoDialog.showModal();
  }));

  closePhoto.addEventListener('click', () => photoDialog.close());
  photoDialog.addEventListener('click', event => {
    if (event.target === photoDialog) photoDialog.close();
  });
}

if (page === 'schedule') {
  const scheduleColumns = [...document.querySelectorAll('.schedule-day-column')];
  const scheduleFrame = document.querySelector('.schedule-board-frame');
  const scheduleStage = document.querySelector('.schedule-board-stage');
  const scheduleBoard = document.querySelector('.schedule-board');
  const scheduleFitButton = document.querySelector('[data-schedule-fit]');
  const scheduleZoomLevel = document.querySelector('[data-schedule-zoom-level]');
  const scheduleFocusButtons = [...document.querySelectorAll('[data-schedule-focus]')];
  const scheduleZoomButtons = [...document.querySelectorAll('[data-schedule-zoom]')];
  const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  let scheduleScale = 1;
  let scheduleView = 'fit';

  const getFitScale = () => Math.min(1, (scheduleFrame.clientWidth - 2) / scheduleBoard.offsetWidth);
  const updateScheduleScale = (nextScale, focusIndex = null) => {
    scheduleScale = Math.max(getFitScale(), Math.min(1.4, nextScale));
    scheduleBoard.style.transform = `scale(${scheduleScale})`;
    scheduleStage.style.width = `${scheduleBoard.offsetWidth * scheduleScale}px`;
    scheduleStage.style.height = `${scheduleBoard.offsetHeight * scheduleScale}px`;
    scheduleZoomLevel.textContent = scheduleView === 'fit' ? 'Fit' : `${Math.round(scheduleScale * 100)}%`;
    scheduleFitButton.classList.toggle('active', scheduleView === 'fit');
    if (focusIndex !== null) {
      const activeColumn = scheduleColumns[focusIndex];
      const targetLeft = (activeColumn.offsetLeft + activeColumn.offsetWidth / 2) * scheduleScale - scheduleFrame.clientWidth / 2;
      scheduleFrame.scrollTo({ left: Math.max(0, targetLeft), behavior: prefersReducedMotion ? 'auto' : 'smooth' });
    }
  };
  const fitSchedule = () => {
    scheduleView = 'fit';
    updateScheduleScale(getFitScale());
    scheduleFrame.scrollTo({ left: 0, behavior: prefersReducedMotion ? 'auto' : 'smooth' });
  };
  const focusScheduleDay = index => {
    scheduleView = 'focus';
    selectScheduleColumn(scheduleColumns[index]);
    scheduleFocusButtons.forEach((button, buttonIndex) => button.classList.toggle('active', buttonIndex === index));
    updateScheduleScale(Math.max(getFitScale(), Math.min(1.25, scheduleFrame.clientWidth / (scheduleColumns[index].offsetWidth * 1.25))), index);
  };
  const selectScheduleColumn = activeColumn => {
    scheduleColumns.forEach(column => column.classList.toggle('selected', column === activeColumn));
  };
  scheduleColumns.forEach((column, index) => {
    column.addEventListener('click', () => focusScheduleDay(index));
    column.addEventListener('focus', () => selectScheduleColumn(column));
    column.addEventListener('pointerenter', () => selectScheduleColumn(column));
  });
  scheduleFocusButtons.forEach((button, index) => button.addEventListener('click', () => focusScheduleDay(index)));
  scheduleFitButton.addEventListener('click', () => {
    scheduleFocusButtons.forEach(button => button.classList.remove('active'));
    fitSchedule();
  });
  scheduleZoomButtons.forEach(button => button.addEventListener('click', () => {
    scheduleView = 'manual';
    scheduleFocusButtons.forEach(focusButton => focusButton.classList.remove('active'));
    updateScheduleScale(scheduleScale + (button.dataset.scheduleZoom === 'in' ? .15 : -.15));
  }));
  window.addEventListener('resize', () => {
    if (scheduleView === 'fit') fitSchedule();
  });
  requestAnimationFrame(fitSchedule);
}

if (page === 'home') {
  const discoverTabs = [...document.querySelectorAll('[data-discover-tab]')];
  const discoverPanels = [...document.querySelectorAll('[data-discover-panel]')];
  const discoverExperience = document.querySelector('.discover-greece-experience');
  const selectDiscoverPanel = activeTab => {
    const activePanel = activeTab.dataset.discoverTab;
    discoverExperience.dataset.discoverActive = activePanel;
    discoverTabs.forEach(tab => {
      const selected = tab === activeTab;
      tab.classList.toggle('active', selected);
      tab.setAttribute('aria-selected', String(selected));
      tab.tabIndex = selected ? 0 : -1;
    });
    discoverPanels.forEach(panel => panel.hidden = panel.dataset.discoverPanel !== activePanel);
  };
  discoverTabs.forEach((tab, index) => {
    tab.addEventListener('click', () => selectDiscoverPanel(tab));
    tab.addEventListener('keydown', event => {
      if (!['ArrowLeft', 'ArrowRight'].includes(event.key)) return;
      event.preventDefault();
      const direction = event.key === 'ArrowRight' ? 1 : -1;
      const nextTab = discoverTabs[(index + direction + discoverTabs.length) % discoverTabs.length];
      selectDiscoverPanel(nextTab);
      nextTab.focus();
    });
  });
}

if (page === 'rules') {
  const ruleTabs = [...document.querySelectorAll('[data-rules-panel]')];
  const rulePanels = [...document.querySelectorAll('[data-rules-content]')];
  const selectRulesPanel = activeTab => {
    const activePanel = activeTab.dataset.rulesPanel;
    ruleTabs.forEach(tab => {
      const selected = tab === activeTab;
      tab.classList.toggle('active', selected);
      tab.setAttribute('aria-selected', String(selected));
      tab.tabIndex = selected ? 0 : -1;
    });
    rulePanels.forEach(panel => {
      panel.hidden = panel.dataset.rulesContent !== activePanel;
      if (!panel.hidden) panel.querySelectorAll('.reveal').forEach(element => element.classList.add('visible'));
    });
  };
  ruleTabs.forEach((tab, index) => {
    tab.addEventListener('click', () => selectRulesPanel(tab));
    tab.addEventListener('keydown', event => {
      if (!['ArrowLeft', 'ArrowRight'].includes(event.key)) return;
      event.preventDefault();
      const direction = event.key === 'ArrowRight' ? 1 : -1;
      const nextTab = ruleTabs[(index + direction + ruleTabs.length) % ruleTabs.length];
      selectRulesPanel(nextTab);
      nextTab.focus();
    });
  });
}
